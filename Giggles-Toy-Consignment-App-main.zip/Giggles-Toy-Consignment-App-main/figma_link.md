# Figma link

Link: [Click Here](https://www.figma.com/proto/GHbdPhmmCl4kGS1USZQT9C/Giggles-App?page-id=0%3A1&node-id=243%3A4&viewport=1010%2C464%2C0.39&scaling=scale-down&starting-point-node-id=243%3A4&show-proto-sidebar=1)